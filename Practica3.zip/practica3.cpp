#include "practica3.h"

void seleccionar(){
    string a,b;
    int m;
    unsigned long long int n;
    bool metodo;
    cout << "Ingrese un 1 para ejecutar el metodo 1, 2 para metodo 2 o aplicacion en otro caso: ";
    cin >> m;
    switch (m) {
        case 1:
            cout << "Ingrese 1 si desea codificar o 0 si desea decodificar: ";
            cin >> metodo;
            cout << "Ingrese la semilla: ";
            cin >> n;
            cout<<"Ingrese el nombre del archivo txt: ";cin>>a;
            cout<<"Ingrese el nombre del archivo dat: ";cin>>b;
            metodo1(metodo,n,a,b);
        break;

        case 2:
            cout << "Ingrese 1 si desea codificar o 0 si desea decodificar: ";
            cin >> metodo;
            cout << "Ingrese la semilla: ";
            cin >> n;
            cout<<"Ingrese el nombre del archivo txt: ";cin>>a;
            cout<<"Ingrese el nombre del archivo dat: ";cin>>b;
            metodo2(metodo,n,a,b);
        break;

        default:
            cout << "aplicacion" << endl;
            aplicacion(6,1,15,1);//1.Semilla usuario2.Metodo usuario3.Semilla sudo4.Metodo sudo.
    }
}

void metodo1(bool metodo, unsigned long long int semilla,string a,string b){
    string texto;
    texto=leer_Txt(metodo,a,b);
    bool *cod= new bool [8*texto.length()];
    text2bin(texto,cod);
    separacion(semilla,cod,8*texto.length(), metodo);
    texto=bin2text(texto,cod);
    escribir_Txt(texto,metodo,a,b);
//    for(unsigned long long int i=0; i<8*texto.length();i++){

//        cout << cod[i];
//        if((i+1)%8==0)      cout << endl;
//    }

}

string leer_Txt(bool metodo,string a,string b){
    long long int tam;
    string texto, text;
    char s;
    if(metodo) text=a;
    else text=b;
    /////////////////////////////Tamano
    fstream k(text, ios::in | ios::ate);
    tam=k.tellg();
    k.close();
    //////////////////////////////////////
    fstream k1(text, ios::in | ios::binary);
    for(long long int i=0;i<tam;i++){
        k1.get(s);
        texto.push_back(s);
    }
    k1.close();
    return texto;
}

void text2bin(string texto,bool *cod){
    char s;
    for(unsigned long long int i=0; i<(texto.length()); i++){
        s=char(texto[i]);
        for(unsigned long long int j=0;j<8;j++) cod[8*i+j]=(((s<<j)&0x80)==0x80);
    }
}

void separacion(unsigned long long int semilla, bool *cod, unsigned long long int tam, bool codify){
  short *seg = new short[semilla];
  long long int j=0;
  unsigned short tp=0;
  for(unsigned long long int i=0;i<semilla;i++) seg[i]=-1;
  for(unsigned long long int i=0,l=0; i<tam; i++,j++){
      seg[j]=cod[i];
      if((i+1)%semilla==0 || i==(tam-1)){
          tp=reglas(seg,&cod[semilla*l],tp,semilla,codify);
          for(unsigned long long int k=0;k<semilla;k++) seg[k]=-1;
          l++;
          j=-1;
      }
  }
}

unsigned short reglas(short *seg, bool *data, unsigned short regla, unsigned long long int semilla, bool codify){
    int contador[2]={0,0};
    unsigned short reg=0;
    for(unsigned long long int i=0; i<semilla; i++){
        if(seg[i]!=-1){
            switch (regla){
                case 0: data[i]=1-seg[i];

                break;

                case 1: if(i%2!=0) data[i]=1-seg[i];

                break;

                default: if((i+1)%3==0) data[i]=1-seg[i];
            }

          if(codify) contador[seg[i]]++;
          else contador[data[i]]++;
        }
    }
    if(contador[0]>contador[1]) reg=1;
    else if(contador[0]<contador[1]) reg=2;
    return reg;
}

string bin2text(string texto,bool *cod){
    int a,pot=1;
    for(unsigned long long int i=0; i<(texto.length()); i++){
        a=0;
        pot=1;
        for(unsigned long long int j=0;j<8;j++){
            a+=(cod[j+8*i]*128)/pot;
            pot*=2;
        }
        texto[i]=char(a);
    }

    return texto;
}

void escribir_Txt(string texto, bool metodo,string a,string b){
    string text;
    if(!metodo) text=a;
    else text=b;
    ofstream k2(text,  ios::out | ios::binary);
    k2 << texto;
    k2.close();
}

void metodo2(bool metodo,unsigned long long semilla,string a,string b){
    string texto;
    texto=leer_Txt(metodo,a,b);
    bool *cod= new bool [8*texto.length()];
    text2bin(texto,cod);
    separacion2(semilla,cod,8*texto.length(), metodo);
    texto=bin2text(texto,cod);
    escribir_Txt(texto,metodo,a,b);
}

void separacion2(unsigned long long int semilla, bool *cod, unsigned long long int tam, bool codify){
  short *seg = new short[semilla];
  long long int j=0;
  for(unsigned long long int i=0;i<semilla;i++) seg[i]=-1;
  for(unsigned long long int i=0,l=0; i<tam; i++,j++){
      seg[j]=cod[i];
      if((i+1)%semilla==0 || i==(tam-1)){
          reglas_metodo2(seg,&cod[semilla*l],semilla,codify);
          for(unsigned long long int k=0;k<semilla;k++) seg[k]=-1;
          l++;
          j=-1;
      }
  }
}

void reglas_metodo2(short *seg,bool *data,unsigned long long int semilla,bool codify){
    unsigned long long int j=0;
    for (unsigned long long int i=0;i<semilla;i++){
        if (seg[i]!=-1)j++;
    }
    if (codify){
        data[0]=seg[j-1];
        for (unsigned long long int i=0;i<(j-1);i++){
            data[i+1]=seg[i];
        }
    }
    else {
        data[j-1]=seg[0];
        for (unsigned long long int i=1;i<j;i++) data[i-1]=seg[i];
    }
}

void aplicacion(unsigned long long int semilla,int metodo,unsigned long long int semilla_1,int metodo_1){
    int opc1,opc2;
    string conta,contu,ced;
    if (metodo==1)metodo1(0,semilla,"usuario.txt","usuario.dat");
    else metodo2(0,semilla,"usuario.txt","usuario.dat");
    //if(remove("usuario.dat")!=0)cout<<"Error al removerlo: "<<strerror(errno)<<endl;
    cout<<"1. Ingresar como administrador.\n2. Ingresar como usuario.\n";cin>>opc1;
    cin.ignore();
    switch (opc1) {
        case 1:
            cout<<"Ingrese la contraseña"<<endl;
            std::getline(std::cin,conta);
            //cout<<"Contraseña:"<<conta<<endl;
            if(verifivar_contr(conta,semilla_1,metodo_1)){
                cout<<"1. Registrar un nuevo usuario.\n2. Cancelar."<<endl;cin>>opc2;
                while(opc2==1){
                    registro_usuario();
                    if (metodo==1){metodo1(1,semilla,"usuario.txt","usuario.dat");}
                    else metodo2(1,semilla,"usuario.txt","usuario.dat");
                    cout<<"1. Realizar otro registro.\n2. Salir.";cin>>opc2;
                }
            }
            else cout<<"La contraseña ingresada no es correcta\n"<<endl;
            cout<<"Ha salido\n";
            if(remove("usuario.txt")!=0)cout<<"Error al removerlo: "<<strerror(errno)<<endl;
        break;
        case 2:
            cout<<"Ingrese la cedula\n";
            cin>>ced;
            cout<<"Ingrese la contraseña\n";
            cin>>contu;
            sacar_info(ced,contu);
            if (metodo==1){metodo1(1,semilla,"usuario.txt","usuario.dat");}
            else metodo2(1,semilla,"usuario.txt","usuario.dat");
            if(remove("usuario.txt")!=0)cout<<"Error al removerlo: "<<strerror(errno)<<endl;
        break;
        default:
            break;
    }
    system ("pause");
    system("cls");

}

bool verifivar_contr(string cont,unsigned long long int semilla, int metodo){
    if (metodo==1)metodo1(0,semilla,"sudo.txt","sudo.dat");
    else metodo2(0,semilla,"sudo.txt","sudo.dat");
    long long int tam;
    string texto;
    char s;
    string text="sudo.txt";
    fstream k(text,ios::in | ios::ate);
    tam=k.tellg();
    k.close();
    fstream k1(text,ios::in | ios::binary);
    for (long long int i=0;i<tam;i++){
        k1.get(s);
        texto.push_back(s);
    }
    k1.close();
    if(remove("sudo.txt")!=0)cout<<"Error al removerlo: "<<strerror(errno)<<endl;
    if(cont==texto)return 1;
    else return 0;
}

void registro_usuario(){
    string usuario,contra,saldo,total;
    cout<<"Ingrese una cedula: ";cin>>usuario;cout<<endl;
    bool j=1;
    string cc1;
    ifstream k("usuario.txt");
    while((!k.eof())){
        k>>cc1;
        if (cc1==usuario){
            cout<<"Ya hay un usuario con esta cedula."<<endl;
            j=0;
        }
        else{
            k>>cc1;
            k>>cc1;
        }
    }
    k.close();
    if (j){
        cout<<"Ingrese la contraseña: ";cin>>contra;cout<<endl;
        cout<<"Ingrese el saldo: ";cin>>saldo;cout<<endl;
        total="\n"+usuario+" "+contra+" "+saldo;
        ofstream k("usuario.txt", ios::out | ios::app);
        k<<total;
        k.close();
        cout<<"Se realizo el registro"<<endl;
    }
}

void sacar_info(string cc,string cont){
    int contador=0,c,bander=0;
    unsigned long long int tam=0;
    bool j=1;
    string cc1,cont1,saldo;
    fstream k1("usuario.txt");
    while((!k1.eof())){
        k1>>cc1;
        tam++;
    }
    string datos[tam];
    ifstream k("usuario.txt");
    while((!k.eof())){
        k>>cc1;
        datos[contador]=cc1;
        contador++;
        //cout<<cc1<<endl;
        if (cc1==cc){
            c=contador;
            k>>cont1;
            datos[contador]=cont1;
            contador++;
            if (cont==cont1){
                j=0;
                k>>saldo;
                datos[contador]=saldo;
                contador++;
            }
        }
        else{
            k>>cc1;
            datos[contador]=cc1;
            contador++;
            k>>cc1;
            datos[contador]=cc1;
            contador++;
        }
    }
    k.close();
    if(j){
        cout<<"Cedula, o contraseña incorrectas"<<endl;
    }
    else{
        cout<<"Cualquier accion que realice tendra un costo de 1000 COP"<<endl;
        cout<<"1. Consultar saldo.\n2. Retirar dinero.\n3. Salir."<<endl;
        cin>>bander;
        if (bander == 1) saldo=consultar_saldo(saldo);
        else if  (bander==2) saldo=retirar(saldo);
        datos[c+1]=saldo;
        guarda(datos,contador);
    }
}

string consultar_saldo(string saldo){
    int i=stoi(saldo);
    if((i-1000)<0) cout<<"Su saldo no es suficiente para realizar la consulta."<<endl;
    else{
        i-=1000;
        cout<<"Su saldo disponible menos el costo de la consulta: "<<i<<endl;
    }
    std::string str = std::to_string(i);
    return str;
}

string retirar(string saldo){
    int i=stoi(saldo),retirar;
    cout<<"¿Cuanto dinero desea retirar? ";cin>>retirar;
    if (retirar>(i-1000))cout<<"Su saldo no es suficiente, tenga en cuenta el costo por retirar."<<endl;
    else {
        i=i-1000-retirar;
        cout<<"Retiro exitoso."<<endl;
    }
    std::string str = std::to_string(i);
    return str;
}

void guarda(string *j,int contador){
    ofstream k("usuario.txt");
    string total;
    for (int i=0;i<(contador/3);i++){
        if (i<(contador/3)-1) total=j[(i*3)]+" "+j[(i*3)+1]+" "+j[(i*3)+2]+"\n";
        else total=j[(i*3)]+" "+j[(i*3)+1]+" "+j[(i*3)+2];
        //cout<<total;
        k<<total;
    }
    k.close();
}
