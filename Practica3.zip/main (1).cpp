#include "practica3.h"

int main()
{
    while(true){
        seleccionar();
    }
    return 0;
}
