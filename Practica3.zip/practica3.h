#include <iostream>
#include <fstream>
#include <errno.h>
#include <cstring>

using namespace std;

void seleccionar();
void metodo1(bool metodo, unsigned long long int semilla,string a,string b);
string leer_Txt(bool metodo,string a,string b);
void text2bin(string texto,bool *cod);
void separacion(unsigned long long int semilla, bool *cod, unsigned long long int tam, bool codify);
unsigned short reglas(short *seg, bool *data, unsigned short regla, unsigned long long int semilla, bool codify);
string bin2text(string texto,bool *cod);
void escribir_Txt(string texto, bool metodo,string a,string b);
long long int tamano(char *name);
//metodo 2
void metodo2(bool metodo,unsigned long long semilla,string a,string b);
void separacion2(unsigned long long int semilla, bool *cod, unsigned long long int tam, bool codify);
void reglas_metodo2(short *seg,bool *data,unsigned long long int semilla,bool codify);
//aplicacion
void aplicacion(unsigned long long int semilla,int metodo,unsigned long long int semilla_1,int metodo_1);
bool verifivar_contr(string cont,unsigned long long int semilla, int metodo);
void registro_usuario();
void sacar_info(string cc,string cont);
string consultar_saldo(string saldo);
string retirar(string saldo);
void guarda(string *j,int contador);
